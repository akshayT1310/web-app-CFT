import React from 'react'
import Carts from './Carts'

const App = () => {
  return (
    <div>
    <Carts/>
    </div>
  )
}

export default App